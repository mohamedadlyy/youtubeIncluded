import React,{ Component } from 'react';

class Search extends Component {

state = {
  term : '',
}

inputChangeHandler = (term) => {
  this.setState({term});
  this.props.onSearch(term);
}
  render(){
    return(
      <div className="search-bar">
        <label> Search </label>
        <input value={this.state.term} onChange={event => this.inputChangeHandler(event.target.value)} />
      </div>
    );
  }
}
export default Search;
