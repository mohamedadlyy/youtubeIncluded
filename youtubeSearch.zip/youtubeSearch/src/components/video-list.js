import React from 'react';
import VideoItem from './video-list-items';

const VideoList = (props) => {

const VideoItems = props.videos.map((video) => {
    return (
      <VideoItem
         onVideoSelected={props.onVideoSelected}
         key={video.etag}
         video={video} />
    );
  });


  return(
    <ul className="col-md-4 list-group">
      {VideoItems}
    </ul>
  );

};

export default VideoList
