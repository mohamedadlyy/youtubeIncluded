import React,{ Component } from 'react';
import ReactDOM from 'react-dom';
import youtubeSearch from 'youtube-api-search';
import _ from 'lodash';

import Search from './components/search';
import VideoList from './components/video-list';
import VideoDetail from './components/Video-details';
const API_KEY = 'AIzaSyD-Rwubx3iPClEm_NINYlmKXkdwUgTe-bE';


class App extends Component {

  constructor(props){
    super(props);

    this.state = {
      videos : [],
      selectedVideo : null
     };
     this.videoSearchHandler('new');
  }

  videoSearchHandler = (term) =>{
    youtubeSearch({key:API_KEY, term :term}, (data) => {
      this.setState({
        videos : data,
        selectedVideo : data[0]
      });
    });
  }

selectedHandler = (selectedVideo) =>{
  this.setState({selectedVideo : selectedVideo })
}

  render(){

const videoSearchHandler = _.debounce((term) =>{this.videoSearchHandler(term) }, 300);

    return(
      <div>
        <div>
          <Search onSearch={videoSearchHandler}/>
          <VideoDetail video={this.state.selectedVideo}/>
          <VideoList
            onVideoSelected={this.selectedHandler}
            videos={this.state.videos}/>
       </div>
      </div>
    );
  }
}


ReactDOM.render(<App/>,document.querySelector('.container'));
